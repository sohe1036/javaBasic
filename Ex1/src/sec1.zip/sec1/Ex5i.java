package sec1;

import java.util.Scanner;

public class Ex5i {

	public static void main(String[] args) {
		
		boolean run =true;
		int studentNum =0;
		int[] scores =null;
		Scanner sc = new Scanner(System.in);
		
		While(run) {
			System.out.println("---------------------------------------------");
			System.out.println("1.학생수 | 2.점수입력 | 3.점수리스트 | 4.분석 | 5.종료 ");
			System.out.println("---------------------------------------------");
			System.out.println("선택> ");
		
		int selectNO =sc.nextInt();
		if(selectNO == 1) {
			System.out.println("학생수>");
			studentNum = sc.nextInt();
		
		}
	
	}

}
